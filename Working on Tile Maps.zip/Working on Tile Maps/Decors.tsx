<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Decors" tilewidth="16" tileheight="16" tilecount="98" columns="14">
 <image source="../Pixel Art Trees/FreeCuteTileset/Decors.png" width="224" height="112"/>
</tileset>
